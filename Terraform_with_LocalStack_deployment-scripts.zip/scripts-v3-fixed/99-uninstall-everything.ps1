# ============================================================
# Terraform + LocalStack Environment - Full Uninstall & Cleanup
# Script: 99-uninstall-everything.ps1
#
# What this script removes:
#   - LocalStack Docker container and image
#   - Lambda Python 3.11 runtime image (public.ecr.aws/lambda/python:3.11)
#   - Terraform (via Chocolatey)
#   - AWS CLI v2 (via MSI uninstaller)
#   - LocalStack CLI (via pip)
#   - tflocal (via pip)
#   - AWS CLI credentials / config files (~\.aws\)
#   - Terraform lab files (C:\terraform-labs\)
#   - Python (via Chocolatey)         -- optional, see prompt
#   - Docker Desktop                  -- optional, see prompt
#   - Chocolatey                      -- optional, see prompt
#
# %TEMP% and cache folders cleaned:
#   - %TEMP%\AWSCLIV2.msi             -- AWS CLI installer download
#   - %TEMP%\DockerDesktopInstaller.exe -- Docker installer download
#   - %TEMP%\chocolatey\              -- Chocolatey package staging
#   - %TEMP%\Amazon\                  -- AWS CLI MSI staging
#   - %TEMP%\Docker\                  -- Docker install staging
#   - %TEMP%\pip-*                    -- pip build/unpack temp folders
#   - %TEMP%\MSI*.LOG / MSI*.tmp      -- Windows Installer logs
#   - %TEMP%\wsl_update_*.msi         -- WSL kernel update installer
#   - %TEMP%\docker-*.log             -- Docker installer logs
#   - %LOCALAPPDATA%\pip\Cache\       -- pip persistent HTTP cache
#
# Run this script:
#   1. Open PowerShell as Administrator
#   2. Run: .\99-uninstall-everything.ps1
#
# You will be prompted before removing Docker Desktop,
# Python, and Chocolatey since those may be used by other
# things on your machine.
# ============================================================

Write-Host ""
Write-Host "=============================================" -ForegroundColor Red
Write-Host "  Terraform + LocalStack Full Uninstall     " -ForegroundColor Red
Write-Host "=============================================" -ForegroundColor Red
Write-Host ""
Write-Host "  This will remove all components installed" -ForegroundColor Yellow
Write-Host "  by 00-terraform-env-setup.ps1 and all" -ForegroundColor Yellow
Write-Host "  Terraform lab files under C:\terraform-labs\" -ForegroundColor Yellow
Write-Host ""

$confirm = Read-Host "  Are you sure you want to continue? (yes / no)"
if ($confirm -ne "yes") {
    Write-Host ""
    Write-Host "  Uninstall cancelled." -ForegroundColor Green
    exit
}
Write-Host ""


# ==============================================================
#  STEP 1: STOP AND REMOVE LOCALSTACK (DOCKER)
# ==============================================================
Write-Host "[1] Stopping and removing LocalStack container and image..." -ForegroundColor Cyan

$dockerRunning = $false
try {
    docker info 2>$null | Out-Null
    if ($LASTEXITCODE -eq 0) { $dockerRunning = $true }
} catch {}

if ($dockerRunning) {
    # Stop container if running
    $running = docker ps --filter "name=localstack" -q 2>$null
    if ($running) {
        Write-Host "  Stopping LocalStack container..." -ForegroundColor Yellow
        docker stop localstack 2>$null
        Write-Host "  Container stopped." -ForegroundColor Green
    } else {
        Write-Host "  [SKIP] LocalStack container is not running." -ForegroundColor Gray
    }

    # Remove image
    $image = docker images "localstack/localstack" -q 2>$null
    if ($image) {
        Write-Host "  Removing LocalStack Docker image..." -ForegroundColor Yellow
        docker rmi localstack/localstack --force 2>$null
        Write-Host "  Image removed." -ForegroundColor Green
    } else {
        Write-Host "  [SKIP] LocalStack Docker image not found." -ForegroundColor Gray
    }

    # Remove any dangling images left by LocalStack lambda runners
    Write-Host "  Pruning unused Docker images (lambda runners)..." -ForegroundColor Yellow
    docker image prune -f 2>$null
    Write-Host "  Done." -ForegroundColor Green

    # Remove Lambda Python 3.11 runtime image pulled during Lab 04
    Write-Host "  Removing Lambda Python 3.11 runtime image..." -ForegroundColor Yellow
    $lambdaImage = docker images "public.ecr.aws/lambda/python" --filter "reference=public.ecr.aws/lambda/python:3.11" -q 2>$null
    if ($lambdaImage) {
        docker rmi public.ecr.aws/lambda/python:3.11 --force 2>$null
        Write-Host "  Lambda runtime image removed." -ForegroundColor Green
    } else {
        Write-Host "  [SKIP] Lambda runtime image not found." -ForegroundColor Gray
    }
} else {
    Write-Host "  [SKIP] Docker is not running. Skipping container/image removal." -ForegroundColor Gray
    Write-Host "         Start Docker Desktop first if you want to remove the images." -ForegroundColor Gray
}
Write-Host ""


# ==============================================================
#  STEP 2: UNINSTALL LOCALSTACK CLI
# ==============================================================
Write-Host "[2] Removing LocalStack CLI (pip)..." -ForegroundColor Cyan

$lsCheck = pip show localstack 2>$null
if ($lsCheck -match "Name: localstack") {
    pip uninstall localstack -y
    Write-Host "  LocalStack CLI removed." -ForegroundColor Green
} else {
    Write-Host "  [SKIP] LocalStack CLI is not installed." -ForegroundColor Gray
}
Write-Host ""


# ==============================================================
#  STEP 3: UNINSTALL TFLOCAL
# ==============================================================
Write-Host "[3] Removing tflocal (pip)..." -ForegroundColor Cyan

$tlCheck = pip show terraform-local 2>$null
if ($tlCheck -match "Name: terraform-local") {
    pip uninstall terraform-local -y
    Write-Host "  tflocal removed." -ForegroundColor Green
} else {
    Write-Host "  [SKIP] tflocal is not installed." -ForegroundColor Gray
}
Write-Host ""


# ==============================================================
#  STEP 4: UNINSTALL TERRAFORM
# ==============================================================
Write-Host "[4] Removing Terraform..." -ForegroundColor Cyan

$tfInstalled = $false
try {
    terraform -version 2>$null | Out-Null
    if ($LASTEXITCODE -eq 0) { $tfInstalled = $true }
} catch {}

if ($tfInstalled) {
    $chocoAvailable = $false
    try {
        choco --version 2>$null | Out-Null
        if ($LASTEXITCODE -eq 0) { $chocoAvailable = $true }
    } catch {}

    if ($chocoAvailable) {
        choco uninstall terraform -y
        Write-Host "  Terraform removed via Chocolatey." -ForegroundColor Green
    } else {
        # Fall back to finding and removing the binary manually
        $tfPath = Get-Command terraform -ErrorAction SilentlyContinue | Select-Object -ExpandProperty Source
        if ($tfPath) {
            Remove-Item $tfPath -Force
            Write-Host "  Terraform binary removed from: $tfPath" -ForegroundColor Green
        } else {
            Write-Host "  [!!] Could not locate Terraform binary. Remove manually." -ForegroundColor Red
        }
    }
} else {
    Write-Host "  [SKIP] Terraform is not installed." -ForegroundColor Gray
}
Write-Host ""


# ==============================================================
#  STEP 5: UNINSTALL AWS CLI v2
# ==============================================================
Write-Host "[5] Removing AWS CLI v2..." -ForegroundColor Cyan

$awsReg = Get-ItemProperty `
    "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*" `
    -ErrorAction SilentlyContinue |
    Where-Object { $_.DisplayName -like "*AWS Command Line Interface*" }

if ($awsReg) {
    $productCode = $awsReg.PSChildName
    Write-Host "  Uninstalling AWS CLI (product code: $productCode)..." -ForegroundColor Yellow
    Start-Process msiexec.exe -Wait -ArgumentList "/x $productCode /quiet"
    Write-Host "  AWS CLI v2 removed." -ForegroundColor Green
} else {
    Write-Host "  [SKIP] AWS CLI is not installed (not found in registry)." -ForegroundColor Gray
}

# Remove AWS config and credentials files
$awsConfigDir = "$env:USERPROFILE\.aws"
if (Test-Path $awsConfigDir) {
    Write-Host "  Removing AWS config files ($awsConfigDir)..." -ForegroundColor Yellow
    Remove-Item $awsConfigDir -Recurse -Force
    Write-Host "  AWS config files removed." -ForegroundColor Green
} else {
    Write-Host "  [SKIP] No AWS config folder found." -ForegroundColor Gray
}
Write-Host ""


# ==============================================================
#  STEP 6: REMOVE TERRAFORM LAB FILES
# ==============================================================
Write-Host "[6] Removing Terraform lab files (C:\terraform-labs\)..." -ForegroundColor Cyan

if (Test-Path "C:\terraform-labs") {
    Remove-Item "C:\terraform-labs" -Recurse -Force
    Write-Host "  C:\terraform-labs removed." -ForegroundColor Green
} else {
    Write-Host "  [SKIP] C:\terraform-labs does not exist." -ForegroundColor Gray
}
Write-Host ""


# ==============================================================
#  STEP 7: CLEAN UP %TEMP% AND CACHE FOLDERS
# ==============================================================
# Every tool installed by 00-terraform-env-setup.ps1 leaves
# files behind in %TEMP% and related cache directories.
# This step removes all of them.
#
# What gets cleaned:
#   %TEMP%\AWSCLIV2.msi              - AWS CLI MSI installer download
#   %TEMP%\DockerDesktopInstaller.exe - Docker Desktop installer download
#   %TEMP%\chocolatey\               - Chocolatey package staging folder
#                                      (contains terraform, python downloads)
#   %TEMP%\Amazon\                   - AWS CLI installer staging folder
#   %TEMP%\Docker\                   - Docker Desktop install staging folder
#   %TEMP%\pip-*                     - pip build/unpack/wheel temp folders
#   %TEMP%\MSI*.LOG                  - Windows Installer log files
#                                      (left by AWS CLI and Docker MSI installs)
#   %TEMP%\MSI*.tmp                  - Windows Installer temp files
#   %TEMP%\wsl_update_*.msi          - WSL kernel update installer
#   %TEMP%\docker-*.log              - Docker installer log files
#   %LOCALAPPDATA%\pip\Cache\        - pip HTTP cache (persists across sessions)
# ==============================================================
Write-Host "[7] Cleaning up %TEMP% and cache folders..." -ForegroundColor Cyan
Write-Host "    Location: $env:TEMP" -ForegroundColor Gray
Write-Host ""

$totalRemoved = 0

function Remove-IfExists {
    param([string]$Path, [string]$Label, [switch]$Wildcard)
    if ($Wildcard) {
        $items = Get-Item "$Path" -ErrorAction SilentlyContinue
    } else {
        $items = @(Get-Item $Path -ErrorAction SilentlyContinue)
    }
    foreach ($item in $items) {
        if ($item -and (Test-Path $item.FullName)) {
            try {
                Remove-Item $item.FullName -Recurse -Force -ErrorAction SilentlyContinue
                Write-Host ("  Deleted: {0}" -f $item.FullName) -ForegroundColor Gray
                $script:totalRemoved++
            } catch {
                Write-Host ("  [WARN] Could not delete: {0}" -f $item.FullName) -ForegroundColor Yellow
            }
        }
    }
}

# ── Installer downloads ───────────────────────────────────────
Write-Host "  Installer downloads..." -ForegroundColor White
Remove-IfExists "$env:TEMP\AWSCLIV2.msi"               "AWS CLI MSI"
Remove-IfExists "$env:TEMP\DockerDesktopInstaller.exe"  "Docker Desktop installer"

# ── Chocolatey staging folder ─────────────────────────────────
# Created when choco downloads and extracts packages.
# Contains terraform.zip, python installer, and related files.
Write-Host "  Chocolatey staging..." -ForegroundColor White
Remove-IfExists "$env:TEMP\chocolatey"  "Chocolatey staging"

# ── AWS CLI installer staging ─────────────────────────────────
# msiexec sometimes creates an Amazon\ subfolder in %TEMP%
# during the AWS CLI v2 installation.
Write-Host "  AWS CLI installer staging..." -ForegroundColor White
Remove-IfExists "$env:TEMP\Amazon"  "AWS CLI staging"

# ── Docker installer staging ──────────────────────────────────
# Docker Desktop extracts files here during installation.
Write-Host "  Docker installer staging..." -ForegroundColor White
Remove-IfExists "$env:TEMP\Docker"  "Docker staging"

# ── pip temp folders ──────────────────────────────────────────
# pip creates these when building/unpacking packages such as
# localstack and terraform-local. Pattern: pip-build-*, pip-unpack-*,
# pip-req-*, pip-*.
Write-Host "  pip temp folders..." -ForegroundColor White
$pipFolders = Get-ChildItem -Path $env:TEMP -Filter "pip-*" -ErrorAction SilentlyContinue
foreach ($f in $pipFolders) {
    try {
        Remove-Item $f.FullName -Recurse -Force -ErrorAction SilentlyContinue
        Write-Host ("  Deleted: {0}" -f $f.FullName) -ForegroundColor Gray
        $totalRemoved++
    } catch {
        Write-Host ("  [WARN] Could not delete: {0}" -f $f.FullName) -ForegroundColor Yellow
    }
}

# ── pip persistent HTTP cache ─────────────────────────────────
# pip stores downloaded wheel files here so it does not
# re-download the same package twice. Safe to delete —
# pip will re-download if needed in the future.
Write-Host "  pip HTTP cache..." -ForegroundColor White
$pipCache = "$env:LOCALAPPDATA\pip\Cache"
if (Test-Path $pipCache) {
    try {
        Remove-Item $pipCache -Recurse -Force -ErrorAction SilentlyContinue
        Write-Host "  Deleted: $pipCache" -ForegroundColor Gray
        $totalRemoved++
    } catch {
        Write-Host "  [WARN] Could not delete pip cache: $pipCache" -ForegroundColor Yellow
    }
} else {
    Write-Host "  [SKIP] pip cache folder not found." -ForegroundColor Gray
}

# ── Windows Installer log files ───────────────────────────────
# msiexec (used for AWS CLI install) writes MSI*.LOG and MSI*.tmp
# files to %TEMP%. These are safe to remove after installation.
Write-Host "  Windows Installer logs..." -ForegroundColor White
$msiLogs = Get-ChildItem -Path $env:TEMP -Filter "MSI*.LOG" -ErrorAction SilentlyContinue
$msiTmps = Get-ChildItem -Path $env:TEMP -Filter "MSI*.tmp" -ErrorAction SilentlyContinue
foreach ($f in @($msiLogs) + @($msiTmps)) {
    if ($f) {
        try {
            Remove-Item $f.FullName -Force -ErrorAction SilentlyContinue
            Write-Host ("  Deleted: {0}" -f $f.FullName) -ForegroundColor Gray
            $totalRemoved++
        } catch {}
    }
}

# ── WSL update installer ──────────────────────────────────────
# The wsl --update command sometimes downloads a .msi into %TEMP%.
Write-Host "  WSL update files..." -ForegroundColor White
$wslFiles = Get-ChildItem -Path $env:TEMP -Filter "wsl_update_*.msi" -ErrorAction SilentlyContinue
foreach ($f in $wslFiles) {
    try {
        Remove-Item $f.FullName -Force -ErrorAction SilentlyContinue
        Write-Host ("  Deleted: {0}" -f $f.FullName) -ForegroundColor Gray
        $totalRemoved++
    } catch {}
}

# ── Docker installer logs ─────────────────────────────────────
# Docker Desktop leaves log files matching docker-*.log in %TEMP%.
Write-Host "  Docker installer logs..." -ForegroundColor White
$dockerLogs = Get-ChildItem -Path $env:TEMP -Filter "docker-*.log" -ErrorAction SilentlyContinue
foreach ($f in $dockerLogs) {
    try {
        Remove-Item $f.FullName -Force -ErrorAction SilentlyContinue
        Write-Host ("  Deleted: {0}" -f $f.FullName) -ForegroundColor Gray
        $totalRemoved++
    } catch {}
}

# ── Summary ───────────────────────────────────────────────────
Write-Host ""
if ($totalRemoved -gt 0) {
    Write-Host ("  Removed {0} item(s) from Temp and cache folders." -f $totalRemoved) -ForegroundColor Green
} else {
    Write-Host "  [SKIP] No temp or cache items found (already clean)." -ForegroundColor Gray
}
Write-Host ""


# ==============================================================
#  OPTIONAL: UNINSTALL PYTHON
# ==============================================================
Write-Host "[8] Python..." -ForegroundColor Cyan
Write-Host "  Python may be used by other programs on your machine." -ForegroundColor Gray
$removePython = Read-Host "  Remove Python? (yes / no)"

if ($removePython -eq "yes") {
    $pyInstalled = $false
    try {
        python --version 2>$null | Out-Null
        if ($LASTEXITCODE -eq 0) { $pyInstalled = $true }
    } catch {}

    if ($pyInstalled) {
        $chocoAvailable = $false
        try {
            choco --version 2>$null | Out-Null
            if ($LASTEXITCODE -eq 0) { $chocoAvailable = $true }
        } catch {}

        if ($chocoAvailable) {
            choco uninstall python -y
            Write-Host "  Python removed via Chocolatey." -ForegroundColor Green
        } else {
            Write-Host "  [!!] Chocolatey not available. Uninstall Python via: Settings, Apps, Python." -ForegroundColor Red
        }
    } else {
        Write-Host "  [SKIP] Python is not installed." -ForegroundColor Gray
    }
} else {
    Write-Host "  Skipped. Python kept." -ForegroundColor Gray
}
Write-Host ""


# ==============================================================
#  OPTIONAL: UNINSTALL DOCKER DESKTOP
# ==============================================================
Write-Host "[9] Docker Desktop..." -ForegroundColor Cyan
Write-Host "  Docker Desktop may be used by other projects." -ForegroundColor Gray
$removeDocker = Read-Host "  Remove Docker Desktop? (yes / no)"

if ($removeDocker -eq "yes") {
    $dockerReg = Get-ItemProperty `
        "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*" `
        -ErrorAction SilentlyContinue |
        Where-Object { $_.DisplayName -like "*Docker Desktop*" }

    if ($dockerReg) {
        $dockerUninstaller = $dockerReg.UninstallString
        if ($dockerUninstaller) {
            Write-Host "  Uninstalling Docker Desktop..." -ForegroundColor Yellow
            Start-Process cmd -Wait -ArgumentList "/c `"$dockerUninstaller`" --quiet"
            Write-Host "  Docker Desktop removed." -ForegroundColor Green
        } else {
            Write-Host "  [!!] Could not find Docker Desktop uninstaller. Remove via: Settings, Apps, Docker Desktop." -ForegroundColor Red
        }
    } else {
        Write-Host "  [SKIP] Docker Desktop is not installed." -ForegroundColor Gray
    }

    # Remove Docker data folder
    $dockerData = "$env:APPDATA\Docker"
    if (Test-Path $dockerData) {
        Write-Host "  Removing Docker app data ($dockerData)..." -ForegroundColor Yellow
        Remove-Item $dockerData -Recurse -Force -ErrorAction SilentlyContinue
        Write-Host "  Done." -ForegroundColor Green
    }
} else {
    Write-Host "  Skipped. Docker Desktop kept." -ForegroundColor Gray
}
Write-Host ""


# ==============================================================
#  OPTIONAL: UNINSTALL CHOCOLATEY
# ==============================================================
Write-Host "[10] Chocolatey..." -ForegroundColor Cyan
Write-Host "  Chocolatey may be used by other tools on your machine." -ForegroundColor Gray
$removeChoco = Read-Host "  Remove Chocolatey? (yes / no)"

if ($removeChoco -eq "yes") {
    $chocoInstalled = $false
    try {
        choco --version 2>$null | Out-Null
        if ($LASTEXITCODE -eq 0) { $chocoInstalled = $true }
    } catch {}

    if ($chocoInstalled) {
        Write-Host "  Removing Chocolatey..." -ForegroundColor Yellow
        # Official Chocolatey uninstall method
        $env:ChocolateyInstall = Convert-Path "$((Get-Command choco).Path)\..\.."
        & "$env:ChocolateyInstall\tools\chocolateyInstaller.ps1" -uninstall 2>$null
        # Remove the folder if still there
        if (Test-Path $env:ChocolateyInstall) {
            Remove-Item $env:ChocolateyInstall -Recurse -Force -ErrorAction SilentlyContinue
        }
        Write-Host "  Chocolatey removed." -ForegroundColor Green
        Write-Host "  Note: You may need to manually remove C:\ProgramData\chocolatey" -ForegroundColor Gray
        Write-Host "  from your PATH environment variable." -ForegroundColor Gray
    } else {
        Write-Host "  [SKIP] Chocolatey is not installed." -ForegroundColor Gray
    }
} else {
    Write-Host "  Skipped. Chocolatey kept." -ForegroundColor Gray
}
Write-Host ""


# ==============================================================
#  SUMMARY
# ==============================================================
Write-Host "=============================================" -ForegroundColor Green
Write-Host "  Uninstall Complete                        " -ForegroundColor Green
Write-Host "=============================================" -ForegroundColor Green
Write-Host ""
Write-Host "  Removed (if they were present):" -ForegroundColor White
Write-Host "    - LocalStack container and Docker image" -ForegroundColor Gray
Write-Host "    - Lambda Python 3.11 runtime image" -ForegroundColor Gray
Write-Host "    - LocalStack CLI (pip)" -ForegroundColor Gray
Write-Host "    - tflocal (pip)" -ForegroundColor Gray
Write-Host "    - Terraform" -ForegroundColor Gray
Write-Host "    - AWS CLI v2" -ForegroundColor Gray
Write-Host "    - AWS credentials (~\.aws\)" -ForegroundColor Gray
Write-Host "    - C:\terraform-labs\ (all lab files)" -ForegroundColor Gray
Write-Host "    - %TEMP% installer files and staging folders" -ForegroundColor Gray
Write-Host "    - pip build cache (%LOCALAPPDATA%\pip\Cache\)" -ForegroundColor Gray
Write-Host "    - Chocolatey package staging (%TEMP%\chocolatey\)" -ForegroundColor Gray
Write-Host "    - Windows Installer logs (MSI*.LOG, MSI*.tmp)" -ForegroundColor Gray
Write-Host ""
Write-Host "  A restart is recommended to complete cleanup." -ForegroundColor Yellow
Write-Host ""


# ==============================================================
#  OPTIONAL: DEFRAGMENT HARD DRIVE
# ==============================================================
# Docker images, Python packages, and installation files can
# fragment the file system over time. Running a defrag after
# cleanup helps consolidate free space.
# Note: defrag has no effect on SSDs — Windows detects this
# automatically and will skip or run TRIM instead.
# ==============================================================
Write-Host "=============================================" -ForegroundColor Cyan
Write-Host "  Optional: Defragment Hard Drive           " -ForegroundColor Cyan
Write-Host "=============================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "  Uninstallation is complete. You may want to" -ForegroundColor White
Write-Host "  defragment your hard drive to reclaim and  " -ForegroundColor White
Write-Host "  consolidate the freed space." -ForegroundColor White
Write-Host ""
Write-Host "  Note: On SSDs this runs TRIM instead of a" -ForegroundColor Gray
Write-Host "  full defrag, which is equally beneficial." -ForegroundColor Gray
Write-Host ""

$defrag = Read-Host "  Run defrag / optimize on C: drive now? (yes / no)"

if ($defrag -eq "yes") {
    Write-Host ""
    Write-Host "  Starting drive optimization on C:..." -ForegroundColor Cyan
    Write-Host "  This may take several minutes. Do not close this window." -ForegroundColor Yellow
    Write-Host ""
    # /U  : print progress
    # /V  : verbose output
    # defrag is a system tool available on all Windows versions
    defrag C: /U /V
    Write-Host ""
    Write-Host "  Drive optimization complete." -ForegroundColor Green
} else {
    Write-Host ""
    Write-Host "  Skipped. You can run it manually any time:" -ForegroundColor Gray
    Write-Host "    defrag C: /U /V" -ForegroundColor Gray
    Write-Host "  or via:" -ForegroundColor Gray
    Write-Host "    Start Menu, Defragment and Optimize Drives" -ForegroundColor Gray
}
Write-Host ""
