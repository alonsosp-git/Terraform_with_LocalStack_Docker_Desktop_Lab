# ============================================================
# Lab 02: DynamoDB
# Script: 02-deploy.ps1
# Purpose: Initializes and applies Terraform for Lab 02
# Run AFTER: 01-create-files.ps1
# ============================================================

Set-Location "C:\terraform-labs\lab-02-dynamodb"

Write-Host "Initializing Terraform..." -ForegroundColor Cyan
terraform init

Write-Host "Applying Terraform configuration..." -ForegroundColor Cyan
terraform apply -auto-approve
