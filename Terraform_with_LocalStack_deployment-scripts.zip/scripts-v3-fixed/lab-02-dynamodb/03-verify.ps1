# ============================================================
# Lab 02: DynamoDB
# Script: 03-verify.ps1
# Purpose: Inserts a test item and verifies Lab 02 resources
# Run AFTER: 02-deploy.ps1
# NOTE: Uses [System.IO.File]::WriteAllText() to avoid BOM
#       encoding issues with AWS CLI JSON parsing on Windows
# ============================================================

Set-Location "C:\terraform-labs\lab-02-dynamodb"

Write-Host "Listing DynamoDB tables..." -ForegroundColor Cyan
aws --endpoint-url=http://localhost:4566 dynamodb list-tables

Write-Host "Inserting test item..." -ForegroundColor Cyan
[System.IO.File]::WriteAllText(
  "$PWD\item.json",
  '{"UserId":{"S":"user-001"},"CreatedAt":{"S":"2026-03-12"},"Name":{"S":"Alice"}}'
)
aws --endpoint-url=http://localhost:4566 dynamodb put-item `
  --table-name Users `
  --item file://item.json

Write-Host "Scanning all items in Users table..." -ForegroundColor Cyan
aws --endpoint-url=http://localhost:4566 dynamodb scan --table-name Users

Write-Host "Showing Terraform outputs..." -ForegroundColor Cyan
terraform output
