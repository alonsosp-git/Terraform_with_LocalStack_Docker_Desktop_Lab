# ============================================================
# Lab 02: DynamoDB
# Script: 04-destroy.ps1
# Purpose: Destroys all Lab 02 resources from LocalStack
# Run AFTER: 03-verify.ps1 (when done with lab)
# ============================================================

Set-Location "C:\terraform-labs\lab-02-dynamodb"

Write-Host "Destroying Lab 02 resources..." -ForegroundColor Yellow
terraform destroy -auto-approve

Write-Host "Lab 02 resources destroyed." -ForegroundColor Green
