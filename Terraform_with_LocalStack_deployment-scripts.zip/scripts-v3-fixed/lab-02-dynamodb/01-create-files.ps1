# ============================================================
# Lab 02: DynamoDB
# Script: 01-create-files.ps1
# Purpose: Creates all Terraform files for Lab 02
# Output files:
#   C:\terraform-labs\lab-02-dynamodb\provider.tf
#   C:\terraform-labs\lab-02-dynamodb\main.tf
#   C:\terraform-labs\lab-02-dynamodb\outputs.tf
# ============================================================

$labPath = "C:\terraform-labs\lab-02-dynamodb"

# provider.tf
@'
terraform {
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
  }
}

provider "aws" {
  region                      = "us-east-1"
  access_key                  = "test"
  secret_key                  = "test"
  skip_credentials_validation = true
  skip_metadata_api_check     = true
  skip_requesting_account_id  = true
  s3_use_path_style           = true

  endpoints {
    s3       = "http://localhost:4566"
    ec2      = "http://localhost:4566"
    lambda   = "http://localhost:4566"
    dynamodb = "http://localhost:4566"
    sqs      = "http://localhost:4566"
    iam      = "http://localhost:4566"
    sts      = "http://localhost:4566"
  }
}
'@ | Out-File -FilePath "$labPath\provider.tf" -Encoding utf8

# main.tf
@'
resource "aws_dynamodb_table" "users" {
  name           = "Users"
  billing_mode   = "PAY_PER_REQUEST"
  hash_key       = "UserId"
  range_key      = "CreatedAt"

  attribute {
    name = "UserId"
    type = "S"
  }

  attribute {
    name = "CreatedAt"
    type = "S"
  }

  tags = {
    Environment = "lab"
    Project     = "localstack-demo"
  }
}
'@ | Out-File -FilePath "$labPath\main.tf" -Encoding utf8

# outputs.tf
@'
output "table_name" {
  value = aws_dynamodb_table.users.name
}
output "table_arn" {
  value = aws_dynamodb_table.users.arn
}
'@ | Out-File -FilePath "$labPath\outputs.tf" -Encoding utf8

Write-Host "Lab 02 files created at $labPath" -ForegroundColor Green
Get-ChildItem $labPath
