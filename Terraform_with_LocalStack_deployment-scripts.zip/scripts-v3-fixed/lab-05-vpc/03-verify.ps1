# ============================================================
# Lab 05: VPC & Security Groups
# Script: 03-verify.ps1
# Purpose: Verifies all VPC resources were created correctly
# Run AFTER: 02-deploy.ps1
# ============================================================

Set-Location "C:\terraform-labs\lab-05-vpc"

Write-Host "Listing VPCs..." -ForegroundColor Cyan
aws --endpoint-url=http://localhost:4566 ec2 describe-vpcs `
  --query "Vpcs[].{ID:VpcId,CIDR:CidrBlock,Name:Tags[?Key=='Name']|[0].Value}"

Write-Host "Listing Subnets..." -ForegroundColor Cyan
aws --endpoint-url=http://localhost:4566 ec2 describe-subnets `
  --query "Subnets[].{ID:SubnetId,CIDR:CidrBlock,Name:Tags[?Key=='Name']|[0].Value}"

Write-Host "Listing Security Groups..." -ForegroundColor Cyan
aws --endpoint-url=http://localhost:4566 ec2 describe-security-groups `
  --query "SecurityGroups[].{ID:GroupId,Name:GroupName}"

Write-Host "Showing Terraform outputs..." -ForegroundColor Cyan
terraform output
