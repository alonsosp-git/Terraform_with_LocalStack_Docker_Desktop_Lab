# ============================================================
# Lab 05: VPC
# Script: 04-destroy.ps1
# ============================================================
Set-Location "C:\terraform-labs\lab-05-vpc"
Write-Host "Destroying Lab 05 resources..." -ForegroundColor Yellow
terraform destroy -auto-approve
Write-Host "Lab 05 resources destroyed." -ForegroundColor Green
