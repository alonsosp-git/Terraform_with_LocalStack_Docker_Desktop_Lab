# ============================================================
# Lab 05: VPC
# Script: 02-deploy.ps1
# ============================================================
Set-Location "C:\terraform-labs\lab-05-vpc"
Write-Host "Initializing Terraform..." -ForegroundColor Cyan
terraform init
Write-Host "Applying Terraform configuration..." -ForegroundColor Cyan
terraform apply -auto-approve
