# ============================================================
# Lab 04: Lambda
# Script: 03-deploy.ps1
# ============================================================
Set-Location "C:\terraform-labs\lab-04-lambda"
Write-Host "Initializing Terraform..." -ForegroundColor Cyan
terraform init
Write-Host "Applying Terraform configuration..." -ForegroundColor Cyan
terraform apply -auto-approve
