# ============================================================
# Lab 04: Lambda Functions
# Script: 04-verify.ps1
# Purpose: Invokes the Lambda function and verifies response
# Run AFTER: 03-deploy.ps1
# NOTE: Uses base64-encoded payload instead of file://
#       AWS CLI v2 on Windows does not reliably handle
#       file:// for --payload parameter
# ============================================================

Set-Location "C:\terraform-labs\lab-04-lambda"

Write-Host "Listing Lambda functions..." -ForegroundColor Cyan
aws --endpoint-url=http://localhost:4566 lambda list-functions `
  --query "Functions[].FunctionName"

Write-Host "Invoking my-demo-function..." -ForegroundColor Cyan
$payload = [Convert]::ToBase64String(
  [System.Text.Encoding]::UTF8.GetBytes('{"name":"World","source":"localstack-lab"}')
)
aws --endpoint-url=http://localhost:4566 lambda invoke `
  --function-name my-demo-function `
  --payload $payload `
  response.json

Write-Host "Function response:" -ForegroundColor Cyan
Get-Content response.json

Write-Host "Showing Terraform outputs..." -ForegroundColor Cyan
terraform output
