# ============================================================
# Lab 04: Lambda
# Script: 05-destroy.ps1
# Purpose: Destroys all Lab 04 resources from LocalStack and
#          removes the Lambda Python runtime image pulled from
#          public.ecr.aws/lambda/python:3.11
# Run AFTER: 04-verify.ps1 (when done with lab)
# ============================================================

Set-Location "C:\terraform-labs\lab-04-lambda"

Write-Host "Destroying Lab 04 Terraform resources..." -ForegroundColor Yellow
terraform destroy -auto-approve
Write-Host "Lab 04 resources destroyed." -ForegroundColor Green
Write-Host ""

# ── REMOVE LAMBDA RUNTIME IMAGE ─────────────────────────────
# LocalStack pulls public.ecr.aws/lambda/python:3.11 the first
# time a Lambda function is invoked. It stays on disk after the
# lab and takes ~700 MB. This removes it to free the space.
Write-Host "Removing Lambda Python 3.11 runtime image..." -ForegroundColor Cyan

$dockerRunning = $false
try {
    docker info 2>$null | Out-Null
    if ($LASTEXITCODE -eq 0) { $dockerRunning = $true }
} catch {}

if ($dockerRunning) {
    $imageId = docker images "public.ecr.aws/lambda/python" --filter "reference=public.ecr.aws/lambda/python:3.11" -q 2>$null
    if ($imageId) {
        docker rmi public.ecr.aws/lambda/python:3.11 --force
        Write-Host "  Lambda runtime image removed." -ForegroundColor Green
    } else {
        Write-Host "  [SKIP] Lambda runtime image not found (already removed or never pulled)." -ForegroundColor Gray
    }

    # Also prune any dangling layers left behind
    Write-Host "  Pruning dangling image layers..." -ForegroundColor Yellow
    docker image prune -f 2>$null
    Write-Host "  Done." -ForegroundColor Green
} else {
    Write-Host "  [SKIP] Docker is not running. Start Docker Desktop then run:" -ForegroundColor Yellow
    Write-Host "         docker rmi public.ecr.aws/lambda/python:3.11 --force" -ForegroundColor Gray
}
Write-Host ""
