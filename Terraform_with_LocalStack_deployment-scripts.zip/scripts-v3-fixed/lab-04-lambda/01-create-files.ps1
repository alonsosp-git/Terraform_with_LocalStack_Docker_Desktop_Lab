# ============================================================
# Lab 04: Lambda Functions
# Script: 01-create-files.ps1
# Purpose: Creates all Terraform and Python files for Lab 04
# Output files:
#   C:\terraform-labs\lab-04-lambda\provider.tf
#   C:\terraform-labs\lab-04-lambda\main.tf
#   C:\terraform-labs\lab-04-lambda\outputs.tf
#   C:\terraform-labs\lab-04-lambda\lambda\handler.py
# IMPORTANT: LocalStack must be started with Docker socket mounted
#   docker run --rm -d -p 4566:4566 \
#     -v /var/run/docker.sock:/var/run/docker.sock \
#     --name localstack localstack/localstack:3.8.1
# ============================================================

$labPath = "C:\terraform-labs\lab-04-lambda"

# Create lambda subfolder
New-Item -ItemType Directory -Force -Path "$labPath\lambda" | Out-Null

# provider.tf
@'
terraform {
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
  }
}

provider "aws" {
  region                      = "us-east-1"
  access_key                  = "test"
  secret_key                  = "test"
  skip_credentials_validation = true
  skip_metadata_api_check     = true
  skip_requesting_account_id  = true
  s3_use_path_style           = true

  endpoints {
    s3       = "http://localhost:4566"
    ec2      = "http://localhost:4566"
    lambda   = "http://localhost:4566"
    dynamodb = "http://localhost:4566"
    sqs      = "http://localhost:4566"
    iam      = "http://localhost:4566"
    sts      = "http://localhost:4566"
  }
}
'@ | Out-File -FilePath "$labPath\provider.tf" -Encoding utf8

# lambda/handler.py - uses WriteAllText to avoid BOM
[System.IO.File]::WriteAllText(
  "$labPath\lambda\handler.py",
  @"
import json
import os

def lambda_handler(event, context):
    env = os.environ.get('ENVIRONMENT', 'unknown')
    print(f'Received event: {json.dumps(event)}')
    return {
        'statusCode': 200,
        'body': json.dumps({
            'message': 'Hello from Lambda!',
            'environment': env,
            'event': event
        })
    }
"@
)

# main.tf
@'
resource "aws_iam_role" "lambda_role" {
  name = "lambda-execution-role"
  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Action    = "sts:AssumeRole"
      Effect    = "Allow"
      Principal = { Service = "lambda.amazonaws.com" }
    }]
  })
}

data "archive_file" "lambda_zip" {
  type        = "zip"
  source_dir  = "${path.module}/lambda"
  output_path = "${path.module}/lambda.zip"
}

resource "aws_lambda_function" "my_function" {
  filename         = data.archive_file.lambda_zip.output_path
  function_name    = "my-demo-function"
  role             = aws_iam_role.lambda_role.arn
  handler          = "handler.lambda_handler"
  runtime          = "python3.11"
  source_code_hash = data.archive_file.lambda_zip.output_base64sha256

  environment {
    variables = {
      ENVIRONMENT = "localstack-lab"
    }
  }
}
'@ | Out-File -FilePath "$labPath\main.tf" -Encoding utf8

# outputs.tf
@'
output "function_name" {
  value = aws_lambda_function.my_function.function_name
}
output "function_arn" {
  value = aws_lambda_function.my_function.arn
}
'@ | Out-File -FilePath "$labPath\outputs.tf" -Encoding utf8

Write-Host "Lab 04 files created at $labPath" -ForegroundColor Green
Get-ChildItem $labPath -Recurse
