# ============================================================
# Lab 04: Lambda Functions
# Script: 02-restart-localstack-for-lambda.ps1
# Purpose: Restarts LocalStack with Docker socket mounted
#          (required for Lambda - without this Lambda fails
#          with "Docker not available" error)
# Run AFTER: 01-create-files.ps1
# Run BEFORE: 03-deploy.ps1
# ============================================================

Write-Host "Stopping current LocalStack container..." -ForegroundColor Yellow
docker stop localstack

Write-Host "Starting LocalStack with Docker socket mounted (required for Lambda)..." -ForegroundColor Cyan
docker run --rm -d `
  -p 4566:4566 `
  -v /var/run/docker.sock:/var/run/docker.sock `
  --name localstack `
  localstack/localstack:3.8.1

Write-Host "Waiting 15 seconds for LocalStack to start..." -ForegroundColor Yellow
Start-Sleep -Seconds 15

Write-Host "Verifying LocalStack health..." -ForegroundColor Cyan
curl http://localhost:4566/_localstack/health

Write-Host "LocalStack ready for Lambda!" -ForegroundColor Green
