# ============================================================
# Lab 01: S3 Buckets
# Script: 02-deploy.ps1
# Purpose: Initializes and applies Terraform for Lab 01
# Run AFTER: 01-create-files.ps1
# ============================================================

Set-Location "C:\terraform-labs\lab-01-s3"

Write-Host "Initializing Terraform..." -ForegroundColor Cyan
terraform init

Write-Host "Applying Terraform configuration..." -ForegroundColor Cyan
terraform apply -auto-approve
