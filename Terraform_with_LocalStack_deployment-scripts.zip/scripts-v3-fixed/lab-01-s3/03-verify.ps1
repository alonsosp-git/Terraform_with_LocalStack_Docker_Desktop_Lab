# ============================================================
# Lab 01: S3 Buckets
# Script: 03-verify.ps1
# Purpose: Verifies Lab 01 resources in LocalStack
# Run AFTER: 02-deploy.ps1
# ============================================================

Set-Location "C:\terraform-labs\lab-01-s3"

Write-Host "Listing all S3 buckets..." -ForegroundColor Cyan
aws --endpoint-url=http://localhost:4566 s3 ls

Write-Host "Listing contents of my-localstack-bucket..." -ForegroundColor Cyan
aws --endpoint-url=http://localhost:4566 s3 ls s3://my-localstack-bucket

Write-Host "Showing Terraform outputs..." -ForegroundColor Cyan
terraform output

# ── OPEN WEBSITE IN BROWSER ─────────────────────────────────
# Opens the static website hosted on the LocalStack S3 bucket.
# The URL uses path-style addressing (required for LocalStack).
Write-Host ""
Write-Host "Opening S3 static website in browser..." -ForegroundColor Cyan
$url = "http://localhost:4566/my-localstack-bucket/index.html"
Start-Process $url
Write-Host "  Opened: $url" -ForegroundColor Green
Write-Host "  (If the page is blank, wait a few seconds and refresh)" -ForegroundColor Gray
