# ============================================================
# Lab 01: S3 Buckets
# Script: 01-create-files.ps1
# Purpose: Creates all Terraform files for Lab 01
# Output files:
#   C:\terraform-labs\lab-01-s3\provider.tf
#   C:\terraform-labs\lab-01-s3\main.tf
#   C:\terraform-labs\lab-01-s3\variables.tf
#   C:\terraform-labs\lab-01-s3\outputs.tf
#   C:\terraform-labs\lab-01-s3\index.html
# ============================================================

$labPath = "C:\terraform-labs\lab-01-s3"

# provider.tf
@'
terraform {
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
  }
}

provider "aws" {
  region                      = "us-east-1"
  access_key                  = "test"
  secret_key                  = "test"
  skip_credentials_validation = true
  skip_metadata_api_check     = true
  skip_requesting_account_id  = true
  s3_use_path_style           = true

  endpoints {
    s3       = "http://localhost:4566"
    ec2      = "http://localhost:4566"
    lambda   = "http://localhost:4566"
    dynamodb = "http://localhost:4566"
    sqs      = "http://localhost:4566"
    iam      = "http://localhost:4566"
    sts      = "http://localhost:4566"
  }
}
'@ | Out-File -FilePath "$labPath\provider.tf" -Encoding utf8

# main.tf
@'
# Create an S3 bucket
resource "aws_s3_bucket" "my_bucket" {
  bucket = var.bucket_name
}

# Enable versioning
resource "aws_s3_bucket_versioning" "my_bucket" {
  bucket = aws_s3_bucket.my_bucket.id
  versioning_configuration {
    status = "Enabled"
  }
}

# Enable server-side encryption
resource "aws_s3_bucket_server_side_encryption_configuration" "my_bucket" {
  bucket = aws_s3_bucket.my_bucket.id
  rule {
    apply_server_side_encryption_by_default {
      sse_algorithm = "AES256"
    }
  }
}

# Configure static website hosting
resource "aws_s3_bucket_website_configuration" "my_bucket" {
  bucket = aws_s3_bucket.my_bucket.id
  index_document { suffix = "index.html" }
  error_document { key    = "error.html" }
}

# Upload a file
resource "aws_s3_object" "index" {
  bucket       = aws_s3_bucket.my_bucket.id
  key          = "index.html"
  source       = "index.html"
  content_type = "text/html"
}
'@ | Out-File -FilePath "$labPath\main.tf" -Encoding utf8

# variables.tf
@'
variable "bucket_name" {
  description = "Name of the S3 bucket"
  type        = string
  default     = "my-localstack-bucket"
}
'@ | Out-File -FilePath "$labPath\variables.tf" -Encoding utf8

# outputs.tf
@'
output "bucket_name" {
  value = aws_s3_bucket.my_bucket.id
}
output "website_endpoint" {
  value = aws_s3_bucket_website_configuration.my_bucket.website_endpoint
}
'@ | Out-File -FilePath "$labPath\outputs.tf" -Encoding utf8

# index.html (required - main.tf uploads this file to S3)
@'
<!DOCTYPE html>
<html>
  <head><title>LocalStack S3 Lab</title></head>
  <body><h1>Hello from LocalStack S3!</h1></body>
</html>
'@ | Out-File -FilePath "$labPath\index.html" -Encoding utf8

Write-Host "Lab 01 files created at $labPath" -ForegroundColor Green
Get-ChildItem $labPath
