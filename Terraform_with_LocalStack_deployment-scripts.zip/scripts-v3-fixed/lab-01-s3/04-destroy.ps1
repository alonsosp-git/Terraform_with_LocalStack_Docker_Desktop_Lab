# ============================================================
# Lab 01: S3 Buckets
# Script: 04-destroy.ps1
# Purpose: Destroys all Lab 01 resources from LocalStack
# Run AFTER: 03-verify.ps1 (when done with lab)
# ============================================================

Set-Location "C:\terraform-labs\lab-01-s3"

Write-Host "Destroying Lab 01 resources..." -ForegroundColor Yellow
terraform destroy -auto-approve

Write-Host "Lab 01 resources destroyed." -ForegroundColor Green
