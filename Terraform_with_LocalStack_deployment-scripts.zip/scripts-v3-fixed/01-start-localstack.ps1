# ============================================================
# Start LocalStack
# Script: 01-start-localstack.ps1
#
# Run this script after every machine restart, before running
# any lab scripts. It will ask which mode you need and start
# LocalStack accordingly.
#
# Options:
#   [1] Standard Start  -- Labs 01-03 (S3, DynamoDB, SQS)
#   [2] Lambda Start    -- Lab 04 only (requires Docker socket)
#   [3] Verify          -- Check if LocalStack is already running
#
# Prerequisites:
#   - Machine has been restarted after running 00-terraform-env-setup.ps1
#   - Docker Desktop is open and fully started (whale icon not animating)
#
# Run this script:
#   1. Open PowerShell as Administrator
#   2. Navigate to the folder containing this script
#   3. Run: .\01-start-localstack.ps1
# ============================================================

Write-Host ""
Write-Host "=============================================" -ForegroundColor Cyan
Write-Host "  Start LocalStack                          " -ForegroundColor Cyan
Write-Host "=============================================" -ForegroundColor Cyan
Write-Host ""


# ==============================================================
#  CHECK: DOCKER IS RUNNING
# ==============================================================
# Before anything else, confirm Docker Desktop is up.
# If Docker is not running the user needs to open it first.
# ==============================================================
Write-Host "Checking Docker Desktop is running..." -ForegroundColor Yellow
$dockerReady = $false
try {
    docker info 2>$null | Out-Null
    if ($LASTEXITCODE -eq 0) { $dockerReady = $true }
} catch {}

if (-not $dockerReady) {
    Write-Host ""
    Write-Host "  [ERROR] Docker Desktop is not running." -ForegroundColor Red
    Write-Host ""
    Write-Host "  Please:" -ForegroundColor Yellow
    Write-Host "    1. Open Docker Desktop from the Start Menu" -ForegroundColor Yellow
    Write-Host "    2. Wait for the whale icon in the system tray to stop animating" -ForegroundColor Yellow
    Write-Host "    3. Run this script again" -ForegroundColor Yellow
    Write-Host ""
    exit 1
}

Write-Host "  Docker Desktop is running." -ForegroundColor Green
Write-Host ""


# ==============================================================
#  MENU
# ==============================================================
Write-Host "  Which mode do you need?" -ForegroundColor White
Write-Host ""
Write-Host "  [1]  Standard Start   --  Labs 01-03  (S3, DynamoDB, SQS)" -ForegroundColor Cyan
Write-Host "       Use this for most labs." -ForegroundColor Gray
Write-Host ""
Write-Host "  [2]  Lambda Start     --  Lab 04 only  (Lambda Functions)" -ForegroundColor Cyan
Write-Host "       Mounts the Docker socket so Lambda can run containers." -ForegroundColor Gray
Write-Host "       Use this INSTEAD of option 1 when doing Lab 04." -ForegroundColor Gray
Write-Host ""
Write-Host "  [3]  Verify           --  Check if LocalStack is running" -ForegroundColor Cyan
Write-Host "       Use this any time to confirm LocalStack is healthy." -ForegroundColor Gray
Write-Host ""

$choice = Read-Host "  Enter 1, 2, or 3"
Write-Host ""


# ==============================================================
#  OPTION 1: STANDARD START  --  Labs 01-03
# ==============================================================
# LocalStack v3.8.1 is free -- no auth token or account needed.
# --rm  removes the container automatically when stopped.
# -d    runs it in the background (detached).
# ==============================================================
if ($choice -eq "1") {

    Write-Host "---------------------------------------------" -ForegroundColor Cyan
    Write-Host "  Standard Start  --  Labs 01-03            " -ForegroundColor Cyan
    Write-Host "---------------------------------------------" -ForegroundColor Cyan
    Write-Host ""

    # Stop any existing LocalStack container first
    $existing = docker ps -a --filter "name=localstack" -q 2>$null
    if ($existing) {
        Write-Host "  Stopping existing LocalStack container..." -ForegroundColor Yellow
        docker stop localstack 2>$null | Out-Null
        Write-Host "  Stopped." -ForegroundColor Gray
    }

    Write-Host "  Starting LocalStack v3.8.1..." -ForegroundColor Yellow
    docker run --rm -d `
        -p 4566:4566 `
        --name localstack `
        localstack/localstack:3.8.1

    if ($LASTEXITCODE -ne 0) {
        Write-Host ""
        Write-Host "  [ERROR] Failed to start LocalStack." -ForegroundColor Red
        Write-Host "  Check that Docker Desktop is fully started and try again." -ForegroundColor Red
        exit 1
    }

    Write-Host ""
    Write-Host "  Waiting 10 seconds for LocalStack to initialize..." -ForegroundColor Yellow
    Start-Sleep -Seconds 10

    Write-Host ""
    Write-Host "  Health check:" -ForegroundColor Cyan
    curl http://localhost:4566/_localstack/health

    Write-Host ""
    Write-Host "=============================================" -ForegroundColor Green
    Write-Host "  LocalStack is ready!                      " -ForegroundColor Green
    Write-Host "=============================================" -ForegroundColor Green
    Write-Host ""
    Write-Host "  You can now run lab scripts for Labs 01, 02, or 03." -ForegroundColor White
    Write-Host ""
    Write-Host "  cd C:\terraform-labs\lab-01-s3  and run .\01-create-files.ps1" -ForegroundColor Gray
    Write-Host "  cd C:\terraform-labs\lab-02-dynamodb  and run .\01-create-files.ps1" -ForegroundColor Gray
    Write-Host "  cd C:\terraform-labs\lab-03-sqs  and run .\01-create-files.ps1" -ForegroundColor Gray
    Write-Host ""


# ==============================================================
#  OPTION 2: LAMBDA START  --  Lab 04 only
# ==============================================================
# Lambda needs to spawn its own Docker containers to execute
# your function code. For this to work, LocalStack itself must
# have access to the Docker daemon via the socket file.
# Without -v /var/run/docker.sock the error is:
#   "Docker not available"
# Use this INSTEAD of option 1 when running Lab 04.
# ==============================================================
} elseif ($choice -eq "2") {

    Write-Host "---------------------------------------------" -ForegroundColor Cyan
    Write-Host "  Lambda Start  --  Lab 04 only             " -ForegroundColor Cyan
    Write-Host "---------------------------------------------" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "  NOTE: This mounts the Docker socket into LocalStack" -ForegroundColor Yellow
    Write-Host "  so Lambda can spawn containers to run your function." -ForegroundColor Yellow
    Write-Host ""

    # Stop any existing LocalStack container first
    $existing = docker ps -a --filter "name=localstack" -q 2>$null
    if ($existing) {
        Write-Host "  Stopping existing LocalStack container..." -ForegroundColor Yellow
        docker stop localstack 2>$null | Out-Null
        Write-Host "  Stopped." -ForegroundColor Gray
    }

    Write-Host "  Starting LocalStack v3.8.1 with Docker socket mounted..." -ForegroundColor Yellow
    docker run --rm -d `
        -p 4566:4566 `
        -v /var/run/docker.sock:/var/run/docker.sock `
        --name localstack `
        localstack/localstack:3.8.1

    if ($LASTEXITCODE -ne 0) {
        Write-Host ""
        Write-Host "  [ERROR] Failed to start LocalStack." -ForegroundColor Red
        Write-Host "  Check that Docker Desktop is fully started and try again." -ForegroundColor Red
        exit 1
    }

    Write-Host ""
    Write-Host "  Waiting 15 seconds for LocalStack to initialize..." -ForegroundColor Yellow
    Start-Sleep -Seconds 15

    Write-Host ""
    Write-Host "  Health check:" -ForegroundColor Cyan
    curl http://localhost:4566/_localstack/health

    Write-Host ""
    Write-Host "=============================================" -ForegroundColor Green
    Write-Host "  LocalStack is ready for Lambda!           " -ForegroundColor Green
    Write-Host "=============================================" -ForegroundColor Green
    Write-Host ""
    Write-Host "  You can now run lab scripts for Lab 04." -ForegroundColor White
    Write-Host ""
    Write-Host "  cd C:\terraform-labs\lab-04-lambda  and run .\01-create-files.ps1" -ForegroundColor Gray
    Write-Host ""
    Write-Host "  Remember: Lambda function creation takes 30-40 seconds. This is normal." -ForegroundColor Yellow
    Write-Host ""


# ==============================================================
#  OPTION 3: VERIFY -- Check health at any time
# ==============================================================
} elseif ($choice -eq "3") {

    Write-Host "---------------------------------------------" -ForegroundColor Cyan
    Write-Host "  Verify LocalStack                         " -ForegroundColor Cyan
    Write-Host "---------------------------------------------" -ForegroundColor Cyan
    Write-Host ""

    # Container status
    Write-Host "  Container status:" -ForegroundColor White
    docker ps --filter "name=localstack" --format "table {{.Names}}`t{{.Status}}`t{{.Ports}}"
    Write-Host ""

    # Check if container is actually running
    $running = docker ps --filter "name=localstack" --filter "status=running" -q 2>$null
    if (-not $running) {
        Write-Host "  [!!] LocalStack container is not running." -ForegroundColor Red
        Write-Host ""
        Write-Host "  To start it, run this script again and choose option 1 or 2." -ForegroundColor Yellow
        Write-Host ""
        exit 1
    }

    # Health endpoint
    Write-Host "  Health endpoint:" -ForegroundColor White
    curl http://localhost:4566/_localstack/health
    Write-Host ""

    # Quick AWS CLI test
    Write-Host "  S3 bucket list (AWS CLI test):" -ForegroundColor White
    aws --endpoint-url=http://localhost:4566 s3 ls
    Write-Host "  (empty = correct if no buckets created yet)" -ForegroundColor Gray
    Write-Host ""

    Write-Host "=============================================" -ForegroundColor Green
    Write-Host "  LocalStack is healthy and ready.          " -ForegroundColor Green
    Write-Host "=============================================" -ForegroundColor Green
    Write-Host ""
    Write-Host "  Management commands:" -ForegroundColor White
    Write-Host "    docker ps                  -- check running containers" -ForegroundColor Gray
    Write-Host "    docker stop localstack     -- stop LocalStack" -ForegroundColor Gray
    Write-Host "    docker logs localstack     -- view LocalStack logs" -ForegroundColor Gray
    Write-Host ""


# ==============================================================
#  INVALID INPUT
# ==============================================================
} else {
    Write-Host "  [ERROR] '$choice' is not a valid option. Please enter 1, 2, or 3." -ForegroundColor Red
    Write-Host "  Run the script again: .\01-start-localstack.ps1" -ForegroundColor Yellow
    Write-Host ""
    exit 1
}
