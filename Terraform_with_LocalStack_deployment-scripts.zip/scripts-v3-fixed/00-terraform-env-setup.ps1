# ============================================================
# Terraform + LocalStack Environment Setup
# Script: 00-terraform-env-setup.ps1
#
# What this script installs (in order):
#   1. Docker Desktop    - Container runtime (LocalStack runs inside it)
#      + WSL update      - Required by Docker on Windows
#   2. Chocolatey        - Windows package manager
#   3. Terraform         - Infrastructure as Code tool
#   4. AWS CLI v2        - Command line tool for AWS / LocalStack
#   5. Python            - Required by LocalStack CLI and tflocal
#   6. LocalStack CLI    - 'localstack' command
#                          NOTE: v4.x needs a paid token to START LocalStack.
#                          We start it via Docker (free v3.8.1) -- see below.
#   7. tflocal           - Terraform wrapper for LocalStack (optional)
#
# Each component is checked before installing.
# If already installed, that step is skipped automatically.
#
# Temp installer files downloaded during setup are deleted when done.
# They are not needed after installation and do not affect the labs.
#
# Run this script:
#   1. Open PowerShell as Administrator
#   2. Navigate to the folder containing this script
#   3. Run: .\00-terraform-env-setup.ps1
#
# After this script finishes:
#   RESTART YOUR MACHINE -- Docker Desktop requires a full reboot.
#   After restart:
#     1. Open Docker Desktop from the Start Menu
#     2. Wait for the whale icon in the system tray to stop animating
#     3. Run .\01-start-localstack.ps1 to start LocalStack
#
# Estimated install time: 5-15 minutes (depending on internet speed)
# ============================================================

Write-Host ""
Write-Host "=============================================" -ForegroundColor Cyan
Write-Host "  Terraform + LocalStack Environment Setup  " -ForegroundColor Cyan
Write-Host "=============================================" -ForegroundColor Cyan
Write-Host ""

Set-ExecutionPolicy Bypass -Scope Process -Force

# Track temp files downloaded so we can delete them when done
$TempFiles = @()


# ==============================================================
#  STEP 1: DOCKER DESKTOP + WSL UPDATE
# ==============================================================
# Docker Desktop must be installed FIRST. LocalStack runs as a
# Docker container, so Docker must exist before anything else.
# WSL2 (Windows Subsystem for Linux) is installed by Docker and
# then updated immediately after to ensure the latest kernel.
# ==============================================================
Write-Host "[1/7] Docker Desktop..." -ForegroundColor Cyan

$dockerInstalled = $false
try {
    $d = docker --version 2>$null
    if ($LASTEXITCODE -eq 0 -and $d) { $dockerInstalled = $true }
} catch {}

if (-not $dockerInstalled) {
    $dockerReg = Get-ItemProperty `
        "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*" `
        -ErrorAction SilentlyContinue |
        Where-Object { $_.DisplayName -like "*Docker Desktop*" }
    if ($dockerReg) { $dockerInstalled = $true }
}

if ($dockerInstalled) {
    Write-Host "  [SKIP] Docker Desktop is already installed." -ForegroundColor Green
} else {
    Write-Host "  Downloading Docker Desktop installer..." -ForegroundColor Yellow
    $dockerInstaller = "$env:TEMP\DockerDesktopInstaller.exe"
    Invoke-WebRequest `
        -Uri "https://desktop.docker.com/win/main/amd64/Docker%20Desktop%20Installer.exe" `
        -OutFile $dockerInstaller
    $TempFiles += $dockerInstaller
    Write-Host "  Installing Docker Desktop (this may take a few minutes)..." -ForegroundColor Yellow
    Start-Process $dockerInstaller -Wait -ArgumentList "install --quiet --accept-license"
    Write-Host "  Docker Desktop installed." -ForegroundColor Green
}

Write-Host "  Updating WSL kernel..." -ForegroundColor Cyan
wsl --update
Write-Host "  WSL update complete." -ForegroundColor Green
Write-Host ""


# ==============================================================
#  STEP 2: CHOCOLATEY
# ==============================================================
# Chocolatey is a Windows package manager (like apt on Linux).
# It lets us install Terraform and Python with single commands.
# ==============================================================
Write-Host "[2/7] Chocolatey..." -ForegroundColor Cyan

$chocoInstalled = $false
try {
    $cv = choco --version 2>$null
    if ($LASTEXITCODE -eq 0 -and $cv) { $chocoInstalled = $true }
} catch {}

if ($chocoInstalled) {
    Write-Host "  [SKIP] Chocolatey is already installed (v$cv)." -ForegroundColor Green
} else {
    Write-Host "  Installing Chocolatey..." -ForegroundColor Yellow
    [System.Net.ServicePointManager]::SecurityProtocol = `
        [System.Net.ServicePointManager]::SecurityProtocol -bor 3072
    iex ((New-Object System.Net.WebClient).DownloadString(
        'https://community.chocolatey.org/install.ps1'))
    Write-Host "  Chocolatey installed." -ForegroundColor Green
}
Write-Host ""


# ==============================================================
#  STEP 3: TERRAFORM
# ==============================================================
# Terraform reads .tf files and creates/manages cloud resources.
# Installed via Chocolatey which registers it in PATH automatically.
# ==============================================================
Write-Host "[3/7] Terraform..." -ForegroundColor Cyan

$terraformInstalled = $false
try {
    $tv = terraform -version 2>$null | Select-Object -First 1
    if ($LASTEXITCODE -eq 0 -and $tv) { $terraformInstalled = $true }
} catch {}

if ($terraformInstalled) {
    Write-Host "  [SKIP] Terraform is already installed ($tv)." -ForegroundColor Green
} else {
    Write-Host "  Installing Terraform via Chocolatey..." -ForegroundColor Yellow
    choco install terraform -y
    Write-Host "  Terraform installed." -ForegroundColor Green
}
Write-Host ""


# ==============================================================
#  STEP 4: AWS CLI v2
# ==============================================================
# The AWS CLI lets us run 'aws' commands against LocalStack to
# verify resources (list S3 buckets, scan DynamoDB tables, etc).
#
# IMPORTANT: Use the official MSI installer, NOT choco install awscli.
# Chocolatey's awscli package does not register in PATH correctly
# on Windows. The MSI method is confirmed working.
# ==============================================================
Write-Host "[4/7] AWS CLI v2..." -ForegroundColor Cyan

$awsInstalled = $false
try {
    $av = aws --version 2>$null
    if ($LASTEXITCODE -eq 0 -and $av) { $awsInstalled = $true }
} catch {}

if (-not $awsInstalled) {
    $awsReg = Get-ItemProperty `
        "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*" `
        -ErrorAction SilentlyContinue |
        Where-Object { $_.DisplayName -like "*AWS Command Line Interface*" }
    if ($awsReg) { $awsInstalled = $true }
}

if ($awsInstalled) {
    Write-Host "  [SKIP] AWS CLI is already installed." -ForegroundColor Green
} else {
    Write-Host "  Downloading AWS CLI v2 MSI..." -ForegroundColor Yellow
    $awsMsi = "$env:TEMP\AWSCLIV2.msi"
    Invoke-WebRequest -Uri "https://awscli.amazonaws.com/AWSCLIV2.msi" -OutFile $awsMsi
    $TempFiles += $awsMsi
    Write-Host "  Installing AWS CLI v2..." -ForegroundColor Yellow
    Start-Process msiexec.exe -Wait -ArgumentList "/I $awsMsi /quiet"
    Write-Host "  AWS CLI v2 installed." -ForegroundColor Green
}
Write-Host ""


# ==============================================================
#  STEP 5: PYTHON
# ==============================================================
# Python is required so pip can install the LocalStack CLI
# and the tflocal wrapper in the next two steps.
# ==============================================================
Write-Host "[5/7] Python..." -ForegroundColor Cyan

$pythonInstalled = $false
try {
    $pv = python --version 2>$null
    if ($LASTEXITCODE -eq 0 -and $pv) { $pythonInstalled = $true }
} catch {}

if ($pythonInstalled) {
    Write-Host "  [SKIP] Python is already installed ($pv)." -ForegroundColor Green
} else {
    Write-Host "  Installing Python via Chocolatey..." -ForegroundColor Yellow
    choco install python -y
    Write-Host "  Python installed." -ForegroundColor Green
}
Write-Host ""

# Reload PATH so pip, python, aws, terraform are all available now
Write-Host "  Reloading PATH..." -ForegroundColor Yellow
$env:Path = `
    [System.Environment]::GetEnvironmentVariable("Path","Machine") + ";" + `
    [System.Environment]::GetEnvironmentVariable("Path","User")


# ==============================================================
#  STEP 6: LOCALSTACK CLI
# ==============================================================
# Provides the 'localstack' command and utility tools.
#
# IMPORTANT: LocalStack CLI v4.x requires a paid auth token to
# run 'localstack start'. We do NOT use that command in these labs.
# We start LocalStack via Docker using free image v3.8.1 instead
# (see 01-start-localstack.ps1).
# ==============================================================
Write-Host "[6/7] LocalStack CLI..." -ForegroundColor Cyan

$localstackInstalled = $false
try {
    $lv = localstack --version 2>$null
    if ($LASTEXITCODE -eq 0 -and $lv) { $localstackInstalled = $true }
} catch {}

if (-not $localstackInstalled) {
    $check = pip show localstack 2>$null
    if ($check -match "Name: localstack") { $localstackInstalled = $true }
}

if ($localstackInstalled) {
    Write-Host "  [SKIP] LocalStack CLI is already installed." -ForegroundColor Green
} else {
    Write-Host "  Installing LocalStack CLI via pip..." -ForegroundColor Yellow
    pip install localstack
    Write-Host "  LocalStack CLI installed." -ForegroundColor Green
}
Write-Host ""


# ==============================================================
#  STEP 7: TFLOCAL
# ==============================================================
# Optional wrapper around 'terraform' that auto-injects
# --endpoint-url=http://localhost:4566 for all LocalStack calls.
# All labs work with plain terraform + provider.tf as well.
# ==============================================================
Write-Host "[7/7] tflocal (Terraform wrapper for LocalStack)..." -ForegroundColor Cyan

$tflocalInstalled = $false
try {
    $tlv = tflocal --version 2>$null
    if ($LASTEXITCODE -eq 0 -and $tlv) { $tflocalInstalled = $true }
} catch {}

if (-not $tflocalInstalled) {
    $check = pip show terraform-local 2>$null
    if ($check -match "Name: terraform-local") { $tflocalInstalled = $true }
}

if ($tflocalInstalled) {
    Write-Host "  [SKIP] tflocal is already installed." -ForegroundColor Green
} else {
    Write-Host "  Installing tflocal via pip..." -ForegroundColor Yellow
    pip install terraform-local
    Write-Host "  tflocal installed." -ForegroundColor Green
}
Write-Host ""


# ==============================================================
#  CONFIGURE AWS CLI FOR LOCALSTACK
# ==============================================================
# LocalStack accepts any credential values. 'test' is the
# standard convention used across all labs.
# We use 'aws configure set' (non-interactive) because
# 'aws configure' hangs waiting for keyboard input.
# ==============================================================
Write-Host "Configuring AWS CLI credentials for LocalStack..." -ForegroundColor Cyan
aws configure set aws_access_key_id     test
aws configure set aws_secret_access_key test
aws configure set region                us-east-1
aws configure set output                json
Write-Host "  AWS CLI configured." -ForegroundColor Green
Write-Host ""


# ==============================================================
#  CLEAN UP TEMP INSTALLER FILES
# ==============================================================
# The .msi and .exe files downloaded above are installer packages
# only. They are NOT needed after installation completes and are
# safe to delete. Nothing in the labs reads from the Temp folder.
# ==============================================================
if ($TempFiles.Count -gt 0) {
    Write-Host "Cleaning up temporary installer files..." -ForegroundColor Yellow
    foreach ($f in $TempFiles) {
        if (Test-Path $f) {
            Remove-Item $f -Force
            Write-Host "  Deleted: $f" -ForegroundColor Gray
        }
    }
    Write-Host "  Done." -ForegroundColor Green
    Write-Host ""
}


# ==============================================================
#  VERIFY ALL INSTALLATIONS
# ==============================================================
Write-Host "=============================================" -ForegroundColor Green
Write-Host "  Verification                              " -ForegroundColor Green
Write-Host "=============================================" -ForegroundColor Green
Write-Host ""

$checks = @(
    @{ Name = "Docker";     Cmd = { docker --version } },
    @{ Name = "Terraform";  Cmd = { terraform -version | Select-Object -First 1 } },
    @{ Name = "AWS CLI";    Cmd = { aws --version } },
    @{ Name = "Python";     Cmd = { python --version } },
    @{ Name = "LocalStack"; Cmd = { localstack --version } },
    @{ Name = "tflocal";    Cmd = { tflocal --version } }
)

foreach ($c in $checks) {
    try {
        $result = & $c.Cmd 2>$null
        if ($result) {
            Write-Host ("  [OK] {0,-14} {1}" -f ($c.Name + ":"), $result) -ForegroundColor Green
        } else {
            Write-Host ("  [!!] {0,-14} not detected" -f ($c.Name + ":")) -ForegroundColor Red
        }
    } catch {
        Write-Host ("  [!!] {0,-14} error checking" -f ($c.Name + ":")) -ForegroundColor Red
    }
}

Write-Host ""
Write-Host "AWS CLI credential configuration:" -ForegroundColor Cyan
aws configure list
Write-Host ""


# ==============================================================
#  NEXT STEPS
# ==============================================================
Write-Host "=============================================" -ForegroundColor Yellow
Write-Host "  NEXT STEPS                                " -ForegroundColor Yellow
Write-Host "=============================================" -ForegroundColor Yellow
Write-Host ""
Write-Host "  1. RESTART your machine now" -ForegroundColor Yellow
Write-Host "     Docker Desktop needs a reboot to finish WSL2 setup." -ForegroundColor Gray
Write-Host ""
Write-Host "  2. After restart, open Docker Desktop from Start Menu." -ForegroundColor Yellow
Write-Host "     Wait for the whale icon in the system tray to stop" -ForegroundColor Gray
Write-Host "     animating before continuing." -ForegroundColor Gray
Write-Host ""
Write-Host "  3. Run the next script:" -ForegroundColor Yellow
Write-Host "     .\01-start-localstack.ps1" -ForegroundColor Cyan
Write-Host "     It will ask which mode you need and start LocalStack" -ForegroundColor Gray
Write-Host "     for you. Use it every time you begin a lab session." -ForegroundColor Gray
Write-Host ""
Write-Host "     The script offers three options:" -ForegroundColor Gray
Write-Host "       [1] Standard Start  -- Labs 01-03 (S3, DynamoDB, SQS)" -ForegroundColor Gray
Write-Host "       [2] Lambda Start    -- Lab 04 only (mounts Docker socket)" -ForegroundColor Gray
Write-Host "       [3] Verify          -- Check LocalStack health any time" -ForegroundColor Gray
Write-Host ""
Write-Host "  Setup complete!" -ForegroundColor Green
Write-Host ""
