# ============================================================
# Lab 03: SQS
# Script: 04-destroy.ps1
# ============================================================
Set-Location "C:\terraform-labs\lab-03-sqs"
Write-Host "Destroying Lab 03 resources..." -ForegroundColor Yellow
terraform destroy -auto-approve
Write-Host "Lab 03 resources destroyed." -ForegroundColor Green
