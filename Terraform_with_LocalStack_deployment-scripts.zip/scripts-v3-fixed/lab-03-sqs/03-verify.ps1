# ============================================================
# Lab 03: SQS Message Queues
# Script: 03-verify.ps1
# Purpose: Sends and receives a test message to verify Lab 03
# Run AFTER: 02-deploy.ps1
# NOTE: Uses [System.IO.File]::WriteAllText() to avoid BOM
#       encoding issues with AWS CLI JSON parsing on Windows
# ============================================================

Set-Location "C:\terraform-labs\lab-03-sqs"

Write-Host "Listing all SQS queues..." -ForegroundColor Cyan
aws --endpoint-url=http://localhost:4566 sqs list-queues

Write-Host "Sending test message to orders-queue..." -ForegroundColor Cyan
[System.IO.File]::WriteAllText(
  "$PWD\message.json",
  '{"orderId":"123","item":"laptop","qty":1}'
)
aws --endpoint-url=http://localhost:4566 sqs send-message `
  --queue-url http://localhost:4566/000000000000/orders-queue `
  --message-body file://message.json

Write-Host "Receiving message from orders-queue..." -ForegroundColor Cyan
aws --endpoint-url=http://localhost:4566 sqs receive-message `
  --queue-url http://localhost:4566/000000000000/orders-queue

Write-Host "Showing Terraform outputs..." -ForegroundColor Cyan
terraform output
