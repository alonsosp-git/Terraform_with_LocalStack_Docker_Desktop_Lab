# ============================================================
# Lab 03: SQS
# Script: 02-deploy.ps1
# ============================================================
Set-Location "C:\terraform-labs\lab-03-sqs"
Write-Host "Initializing Terraform..." -ForegroundColor Cyan
terraform init
Write-Host "Applying Terraform configuration..." -ForegroundColor Cyan
terraform apply -auto-approve
