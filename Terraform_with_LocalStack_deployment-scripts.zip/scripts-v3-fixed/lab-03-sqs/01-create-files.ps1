# ============================================================
# Lab 03: SQS Message Queues
# Script: 01-create-files.ps1
# Purpose: Creates all Terraform files for Lab 03
# Output files:
#   C:\terraform-labs\lab-03-sqs\provider.tf
#   C:\terraform-labs\lab-03-sqs\main.tf
#   C:\terraform-labs\lab-03-sqs\outputs.tf
# ============================================================

$labPath = "C:\terraform-labs\lab-03-sqs"

# provider.tf
@'
terraform {
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
  }
}

provider "aws" {
  region                      = "us-east-1"
  access_key                  = "test"
  secret_key                  = "test"
  skip_credentials_validation = true
  skip_metadata_api_check     = true
  skip_requesting_account_id  = true
  s3_use_path_style           = true

  endpoints {
    s3       = "http://localhost:4566"
    ec2      = "http://localhost:4566"
    lambda   = "http://localhost:4566"
    dynamodb = "http://localhost:4566"
    sqs      = "http://localhost:4566"
    iam      = "http://localhost:4566"
    sts      = "http://localhost:4566"
  }
}
'@ | Out-File -FilePath "$labPath\provider.tf" -Encoding utf8

# main.tf
@'
# Dead Letter Queue
resource "aws_sqs_queue" "orders_dlq" {
  name                      = "orders-dlq"
  message_retention_seconds = 1209600
}

# Main Queue
resource "aws_sqs_queue" "orders" {
  name                       = "orders-queue"
  visibility_timeout_seconds = 30
  receive_wait_time_seconds  = 10
  message_retention_seconds  = 86400

  redrive_policy = jsonencode({
    deadLetterTargetArn = aws_sqs_queue.orders_dlq.arn
    maxReceiveCount     = 3
  })

  tags = {
    Environment = "lab"
    Project     = "localstack-demo"
  }
}

# FIFO Queue
resource "aws_sqs_queue" "payments" {
  name                        = "payments-queue.fifo"
  fifo_queue                  = true
  content_based_deduplication = true
}
'@ | Out-File -FilePath "$labPath\main.tf" -Encoding utf8

# outputs.tf
@'
output "orders_queue_url" {
  value = aws_sqs_queue.orders.url
}
output "orders_dlq_url" {
  value = aws_sqs_queue.orders_dlq.url
}
output "payments_queue_url" {
  value = aws_sqs_queue.payments.url
}
'@ | Out-File -FilePath "$labPath\outputs.tf" -Encoding utf8

Write-Host "Lab 03 files created at $labPath" -ForegroundColor Green
Get-ChildItem $labPath
